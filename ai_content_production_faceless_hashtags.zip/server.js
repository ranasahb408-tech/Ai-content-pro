require("dotenv").config();
const express=require("express"), cors=require("cors"), bcrypt=require("bcryptjs"), jwt=require("jsonwebtoken"), crypto=require("crypto");
const {OpenAI}=require("openai");
const {Pool}=require("pg");
const path=require("path");

const app=express();
const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET;
if(process.env.NODE_ENV==='production' && (!JWT_SECRET || JWT_SECRET.length<32)) throw new Error('JWT_SECRET must be set to a strong secret in production');

const allowedOrigin=process.env.CORS_ORIGIN||true;
app.use(cors({origin:allowedOrigin}));
app.use(express.json({limit:'1mb'}));
app.use(express.static(path.join(__dirname,'public')));

const pool=new Pool({connectionString:process.env.DATABASE_URL||undefined,ssl:process.env.DATABASE_URL?{rejectUnauthorized:false}:false});
const PLANS={free:{credits:10,price:0},pro:{credits:500,price:499},business:{credits:2500,price:1999}};

async function initDb(){
 if(!process.env.DATABASE_URL){
   if(process.env.NODE_ENV==='production') throw new Error('DATABASE_URL is required in production');
   return;
 }
 await pool.query(`CREATE TABLE IF NOT EXISTS users(id UUID PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password_hash TEXT NOT NULL,plan TEXT NOT NULL DEFAULT 'free',credits INTEGER NOT NULL DEFAULT 10,generations INTEGER NOT NULL DEFAULT 0,admin BOOLEAN NOT NULL DEFAULT FALSE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS payments(id BIGSERIAL PRIMARY KEY,reference TEXT UNIQUE NOT NULL,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,plan TEXT NOT NULL,status TEXT NOT NULL,amount INTEGER NOT NULL,provider TEXT NOT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
 CREATE TABLE IF NOT EXISTS generations(id BIGSERIAL PRIMARY KEY,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,type TEXT,language TEXT,tone TEXT,length TEXT,topic TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());`);
}
const db=async(sql,params)=>pool.query(sql,params);
function tokenFor(u){return jwt.sign({id:u.id,email:u.email,admin:u.admin},JWT_SECRET,{expiresIn:'7d'});}
function auth(req,res,next){try{const t=(req.headers.authorization||'').replace(/^Bearer\s+/,'');req.user=jwt.verify(t,JWT_SECRET);next();}catch{res.status(401).json({error:'Login required'});}}
function admin(req,res,next){auth(req,res,async()=>{if(!req.user.admin)return res.status(403).json({error:'Admin only'});next();});}

app.get('/api/health',async(req,res)=>{try{if(process.env.DATABASE_URL) await db('SELECT 1');res.json({ok:true,db:!!process.env.DATABASE_URL});}catch(e){res.status(503).json({ok:false,error:'Database unavailable'});}});

app.post('/api/auth/signup',async(req,res)=>{try{let {name,email,password}=req.body;if(!name||!email||!password||password.length<8)return res.status(400).json({error:'Name, email and password (8+ chars) required'});email=String(email).trim().toLowerCase();let exists=await db('SELECT 1 FROM users WHERE email=$1',[email]);if(exists.rowCount)return res.status(409).json({error:'Email already registered'});let count=await db('SELECT COUNT(*)::int AS n FROM users');let isAdmin=count.rows[0].n===0 && process.env.ADMIN_EMAIL && email===process.env.ADMIN_EMAIL.toLowerCase();let hash=await bcrypt.hash(password,12);let r=await db('INSERT INTO users(id,email,name,password_hash,admin) VALUES($1,$2,$3,$4,$5) RETURNING id,email,name,plan,credits,generations,admin',[crypto.randomUUID(),email,name,hash,!!isAdmin]);let u=r.rows[0];res.json({token:tokenFor(u),user:u});}catch(e){res.status(500).json({error:'Signup failed'});}});
app.post('/api/auth/login',async(req,res)=>{try{let {email,password}=req.body;let r=await db('SELECT * FROM users WHERE email=$1',[String(email||'').toLowerCase()]);let u=r.rows[0];if(!u||!(await bcrypt.compare(password||'',u.password_hash)))return res.status(401).json({error:'Invalid login'});res.json({token:tokenFor(u),user:{name:u.name,email:u.email,plan:u.plan,credits:u.credits,generations:u.generations}});}catch(e){res.status(500).json({error:'Login failed'});}});
app.get('/api/me',auth,async(req,res)=>{let r=await db('SELECT name,email,plan,credits,generations FROM users WHERE id=$1',[req.user.id]);if(!r.rowCount)return res.status(404).json({error:'User not found'});res.json({user:r.rows[0]});});

app.post('/api/generate',auth,async(req,res)=>{try{let u=(await db('SELECT * FROM users WHERE id=$1',[req.user.id])).rows[0];if(!u)return res.status(404).json({error:'User not found'});if(u.credits<1)return res.status(402).json({error:'No credits. Upgrade your plan.'});let {type='Blog / Article',mode='standard',platform='YouTube',duration='60 seconds',visualStyle='Cinematic',voiceStyle='Natural',language='Urdu',tone='Friendly',length='Medium',topic}=req.body;if(!topic)return res.status(400).json({error:'Topic required'});if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'OPENAI_API_KEY is not configured'});const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});const model=process.env.OPENAI_MODEL||'gpt-5.6-luna';const prompt=mode==='faceless'?`Create a complete faceless video package. Platform: ${platform}. Duration: ${duration}. Language: ${language}. Tone: ${tone}. Voice style: ${voiceStyle}. Visual style: ${visualStyle}. Topic: ${topic}. Length: ${length}.
Return only the finished package with: 1) viral hook, 2) title options, 3) full voice-over script, 4) scene-by-scene table/list with timestamps, narration, AI image/video visual prompt, on-screen text and SFX/music cue, 5) CTA, 6) description, 7) hashtag strategy. For hashtags, provide up to 12 highly relevant, high-search-intent hashtags: prioritize 3-4 broad/popular topic hashtags, 4-5 niche topic hashtags, and 2-3 language/audience/platform hashtags. Put the strongest 3 first. Never claim an exact search volume or that a hashtag is currently #1 unless verified by a live platform source. Avoid unrelated generic spam such as #viral or #fyp unless it genuinely matches the platform/topic. Do not repeat hashtags. Do not require a presenter, face, or talking-head footage.`:`Create ${type}. Language: ${language}. Tone: ${tone}. Length: ${length}. Topic: ${topic}. Return only the finished content, no meta commentary.`;const r=await client.responses.create({model,input:prompt});const content=r.output_text||'';await db('UPDATE users SET credits=credits-1,generations=generations+1 WHERE id=$1',[u.id]);await db('INSERT INTO generations(user_id,type,language,tone,length,topic) VALUES($1,$2,$3,$4,$5,$6)',[u.id,type,language,tone,length,topic]);let fresh=(await db('SELECT credits FROM users WHERE id=$1',[u.id])).rows[0];res.json({content,credits:fresh.credits});}catch(e){console.error(e);res.status(500).json({error:'AI generation failed',detail:process.env.NODE_ENV==='development'?e.message:undefined});}});

app.post('/api/payments/create',auth,async(req,res)=>{let {plan}=req.body;if(!PLANS[plan]||plan==='free')return res.status(400).json({error:'Paid plan required'});let ref='PAY-'+Date.now()+'-'+crypto.randomBytes(3).toString('hex');await db('INSERT INTO payments(reference,user_id,plan,status,amount,provider) VALUES($1,$2,$3,$4,$5,$6)',[ref,req.user.id,plan,'pending',PLANS[plan].price,process.env.PAYMENT_PROVIDER||'gateway-ready']);res.json({reference:ref,gateway:process.env.PAYMENT_PROVIDER||'gateway-ready',message:'Payment gateway credentials and verified webhook are required before charging customers.'});});
app.post('/api/payments/webhook',express.raw({type:'application/json'}),(req,res)=>res.status(501).json({error:'Payment webhook is not enabled until provider signature verification is configured.'}));
app.get('/api/admin/stats',admin,async(req,res)=>{let [a,b,c,d]=await Promise.all([db('SELECT COUNT(*)::int n FROM users'),db("SELECT COUNT(*)::int n FROM users WHERE plan<>'free'"),db("SELECT COALESCE(SUM(amount),0)::int n FROM payments WHERE status='paid'"),db('SELECT COUNT(*)::int n FROM generations')]);res.json({users:a.rows[0].n,paidUsers:b.rows[0].n,revenue:c.rows[0].n,generations:d.rows[0].n});});

app.get(/.*/, (req,res)=>res.sendFile(path.join(__dirname,'public/index.html')));
initDb().then(()=>app.listen(PORT,'0.0.0.0',()=>console.log(`AI Content Pro listening on ${PORT}`))).catch(e=>{console.error(e);process.exit(1);});
