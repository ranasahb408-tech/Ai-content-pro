# AI Content Pro — Production Starter

## Included
- Express + PostgreSQL persistence
- JWT authentication and bcrypt password hashing
- AI generation through the OpenAI Responses API
- Free / Pro / Business credit plans
- Admin statistics endpoint
- Render Blueprint (`render.yaml`) with Postgres
- Secrets kept in environment variables
- Production-safe catch-all route and health check

## Important
Payments are **not live yet**. The payment endpoint creates a pending payment record only. Before charging users, implement the selected provider's official API, callback/webhook signature verification, idempotency, and plan activation.

## Deploy on Render
1. Push this folder to GitHub.
2. In Render choose **New → Blueprint** and select the repository containing `render.yaml`.
3. Provide `OPENAI_API_KEY`, `ADMIN_EMAIL`, and `CORS_ORIGIN` when prompted.
4. Render creates the web service and PostgreSQL database from the Blueprint.
5. Check `/api/health` after deployment.

Render supports environment variables for secrets and can connect a Blueprint service to Render Postgres via `fromDatabase`.


## Hashtag generation
The Faceless mode asks the AI for up to 12 relevant, high-search-intent hashtags, with the strongest 3 first. Exact hashtag popularity/search volume changes over time and by platform, so the app does not fabricate numeric search-volume claims. YouTube itself recommends relevant hashtags and warns against over-tagging; it may show popular hashtag suggestions while uploading.
